import Svg, { Ellipse } from "react-native-svg";

export function ImagemAdicionarDespesa() {
  return (
    <Svg width="420" height="228" viewBox="0 0 393 228" fill="none">
      <Ellipse
        cx="121.496"
        cy="24.3398"
        rx="165.419"
        ry="80.2469"
        transform="rotate(-13.3767 121.496 24.3398)"
        fill="#12335E"
      />
      <Ellipse
        cx="371.903"
        cy="64"
        rx="67.752"
        ry="192.907"
        transform="rotate(-56.0194 371.903 64)"
        fill="#BACAE2"
      />
    </Svg>
  );
}
