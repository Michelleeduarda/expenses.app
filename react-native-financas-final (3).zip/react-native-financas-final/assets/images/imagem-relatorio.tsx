import { Ellipse, Svg } from "react-native-svg";

export function ImagemRelatorio() {
  return (
    <Svg width="393" height="54" viewBox="0 0 393 54" fill="none">
      <Ellipse
        cx="200"
        cy="-0.287065"
        rx="210.935"
        ry="53.3322"
        transform="rotate(-1.19317 200 -0.287065)"
        fill="#12335E"
      />
    </Svg>
  );
}
