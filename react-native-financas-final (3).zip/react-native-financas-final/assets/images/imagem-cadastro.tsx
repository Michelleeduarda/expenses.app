import Svg, { Rect } from "react-native-svg";

export function ImagemCadastro() {
  return (
    <Svg width="420" height="172" viewBox="0 0 393 172" fill="none">
      <Rect
        x="152.21"
        y="61.472"
        width="286.154"
        height="247.062"
        rx="54"
        transform="rotate(-63.5876 152.21 61.472)"
        fill="#EBF1FC"
      />
      <Rect
        x="-187"
        y="22.8632"
        width="401.452"
        height="394.468"
        rx="105"
        transform="rotate(-67.8645 -187 22.8632)"
        fill="#12335E"
      />
    </Svg>
  );
}
