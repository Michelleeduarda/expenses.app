import Svg, { Ellipse } from "react-native-svg";

export function ImagemHome() {
  return (
    <Svg width="420" height="341" viewBox="0 0 393 301" fill="none">
      <Ellipse
        cx="308.06"
        cy="70.7168"
        rx="333"
        ry="222.5"
        transform="rotate(13.6323 308.06 70.7168)"
        fill="#12335E"
      />
    </Svg>
  );
}
