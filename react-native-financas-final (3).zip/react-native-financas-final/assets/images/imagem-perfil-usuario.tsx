import Svg, { Rect } from "react-native-svg";

export function ImagemPerfilUsuario() {
  return (
    <Svg width="679" height="763" viewBox="0 0 679 763" fill="none">
      <Rect
        width="330.95"
        height="680.954"
        rx="30"
        transform="matrix(0.767913 0.640555 -0.611225 0.791456 416.217 0)"
        fill="#325380"
        fillOpacity="0.15"
      />
      <Rect
        width="330.949"
        height="695.559"
        rx="30"
        transform="matrix(0.767948 -0.640512 0.610492 0.792022 0 211.977)"
        fill="#325380"
        fillOpacity="0.15"
      />
    </Svg>
  );
}
