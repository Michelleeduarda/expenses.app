import Svg, { Rect } from "react-native-svg";

export function ImagemLogin() {
  return (
    <Svg width="420" height="229" viewBox="0 0 393 229" fill="none">
      <Rect
        x="6.42117"
        y="228.561"
        width="286.154"
        height="247.062"
        rx="54"
        transform="rotate(-105.074 6.42117 228.561)"
        fill="#EBF1FC"
      />
      <Rect
        x="-75"
        y="-146.895"
        width="401.452"
        height="394.468"
        rx="105"
        transform="rotate(-34.4515 -75 -146.895)"
        fill="#12335E"
      />
    </Svg>
  );
}
