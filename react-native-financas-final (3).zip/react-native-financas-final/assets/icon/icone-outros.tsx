import { ClipPath, Defs, G, Path, Rect, Svg } from "react-native-svg";

export function IconeOutros() {
  return (
    <Svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <G clip-path="url(#clip0_134_7)">
        <Path
          d="M19 11C20.0609 11 21.0783 11.4214 21.8285 12.1716C22.5786 12.9217 23 13.9391 23 15C23 16.0609 22.5786 17.0783 21.8285 17.8284C21.0783 18.5786 20.0609 19 19 19H6.00004C4.69999 19.004 3.44951 18.5014 2.51374 17.5989C1.57798 16.6964 1.03054 15.465 0.987486 14.1656C0.944435 12.8663 1.40916 11.6012 2.28313 10.6388C3.1571 9.67631 4.37158 9.09209 5.66904 9.01001C6.31205 7.64996 7.37599 6.53316 8.7033 5.82503C10.0306 5.11689 11.5507 4.85507 13.0384 5.07835C14.5261 5.30162 15.9024 5.99811 16.9634 7.06466C18.0243 8.13122 18.7136 9.51112 18.929 11H19Z"
          stroke="#12335E"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </G>
      <Defs>
        <ClipPath id="clip0_134_7">
          <Rect width="24" height="24" fill="white" />
        </ClipPath>
      </Defs>
    </Svg>
  );
}
