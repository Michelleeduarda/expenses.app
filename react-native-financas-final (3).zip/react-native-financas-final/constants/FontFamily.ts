export const fontFamily = {
  raleway: {
    light: "Raleway_300Light",
    regular: "Raleway_400Regular",
    medium: "Raleway_500Medium",
    semiBold: "Raleway_600SemiBold",
    bold: "Raleway_700Bold",
  },
};
