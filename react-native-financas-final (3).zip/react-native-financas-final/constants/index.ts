import { fontFamily } from "./FontFamily";

import { colors } from "./Colors";

export const theme = {
  colors,
  fontFamily,
};
