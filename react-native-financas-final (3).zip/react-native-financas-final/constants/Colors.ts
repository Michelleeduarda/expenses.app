export const colors = {
  bluePrimary: "#12335E",
  blueSecundary: "#325380",
  blueMedium: "#7A879B",
  blueLight: "#BACAE2",
  blueWhiteLight: "#EBF1FC",
  light: "#F6F7FC",
  redPrimary: "#9E0000",
  redDark: "#8B0000",
  greenPrimary: "#006C11",
  greenDark: "#01540E",
  white: "#ffffff",
};
