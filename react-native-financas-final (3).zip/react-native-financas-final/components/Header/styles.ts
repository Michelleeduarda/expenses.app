import { StyleSheet } from "react-native";

import { theme } from "@/constants";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: 85,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    paddingHorizontal: 20,
  },
  titulo: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 30,
    color: theme.colors.white,
  },
  containerIcone: {
    height: 50,
    width: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: theme.colors.blueWhiteLight,
    borderRadius: 100,
  },
});
