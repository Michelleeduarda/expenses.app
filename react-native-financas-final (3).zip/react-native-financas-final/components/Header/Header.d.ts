interface HeaderProps {
  handleNavigate: () => void;
  user: User | undefined;
}
