import { View, Text, TouchableOpacity } from "react-native";

import { FontAwesome } from "@expo/vector-icons";

import { styles } from "./styles";

export function Header({ handleNavigate, user }: HeaderProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Olá, {user ? user : "Usário"}</Text>
      <TouchableOpacity style={styles.containerIcone} onPress={handleNavigate}>
        <FontAwesome name="user" size={24} color="#12335E" />
      </TouchableOpacity>
    </View>
  );
}
