import React from "react";

import { View, Text } from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { Feather } from "@expo/vector-icons";

import { styles } from "./styles";

export function Alert({ tipo, mensagem }: AlertProps) {
  return (
    <View
      style={[
        styles.container,
        tipo === "sucesso" ? styles.alertSucesso : styles.alertErro,
      ]}
    >
      {tipo === "sucesso" ? (
        <Ionicons
          name="checkmark-done-circle-outline"
          size={29}
          color="#ffffff"
        />
      ) : (
        <Feather name="alert-circle" size={29} color="#ffffff" />
      )}
      <Text style={styles.mensagem}>{mensagem}</Text>
    </View>
  );
}
