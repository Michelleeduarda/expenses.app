interface AlertProps {
  tipo: string;
  mensagem: string;
}
