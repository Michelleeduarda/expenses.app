import React from "react";
import { ActivityIndicator, Text, TouchableOpacity } from "react-native";

import { styles } from "./styles";

export default function Button({ text, onPress, carregando }: ButtonProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      {carregando ? (
        <ActivityIndicator color={"#fff"} size={30} />
      ) : (
        <Text style={styles.textoButton}>{text}</Text>
      )}
    </TouchableOpacity>
  );
}
