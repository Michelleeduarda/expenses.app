import { theme } from "@/constants";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    height: 50,
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: theme.colors.bluePrimary,
    borderRadius: 10,
  },
  textoButton: {
    color: theme.colors.light,
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 16,
  },
});
