interface ButtonProps {
  text: string;
  carregando?: boolean;
  onPress?: () => void;
}
