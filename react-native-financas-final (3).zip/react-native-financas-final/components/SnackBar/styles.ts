import { theme } from "@/constants";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    height: 70,
    position: "absolute",
    top: 35,
    zIndex: 99,
  },
  containerInterno: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 10,
    width: "95%",
    borderRadius: 10,
  },
  containerIcone: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  containerTextos: {
    paddingHorizontal: 5,
    width: "90%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  snackBarSucesso: {
    backgroundColor: theme.colors.greenPrimary,
  },
  snackBarErro: {
    backgroundColor: theme.colors.redPrimary,
  },
  textoSnackBar: {
    fontSize: 16,
    color: theme.colors.white,
    fontFamily: theme.fontFamily.raleway.semiBold,
    marginLeft: 8,
    flexWrap: "wrap",
  },
});
