interface SnackBarProps {
  onClose: () => void;
  mensagem: string;
  tipo: string;
}
