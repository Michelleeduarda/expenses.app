import { View, Text, TouchableOpacity, TextInput } from "react-native";

import { DropDown } from "../Dropdown";

import { theme } from "@/constants";

import { styles } from "./styles";

import { categorias, icones } from "@/data";
import RNDateTimePicker from "@react-native-community/datetimepicker";
import { AntDesign } from "@expo/vector-icons";

import { formatarData } from "@/helper/formatarData";
import Button from "../Button";

export function FiltrosHome({
  handleAbrirCalendario,
  handleInputChange,
  handleFecharFiltro,
  onChange,
  fetcherFiltrarFinancas,
  abrirCalendario,
  setFiltrado,
  formData,
}: FiltrosProps) {
  const renderIcone = (icone: string) => icones[icone];

  const handleButtonBuscar = () => {
    handleFecharFiltro();
    fetcherFiltrarFinancas();
    setFiltrado(true);
  };
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.buttonClose} onPress={handleFecharFiltro}>
        <AntDesign name="close" size={26} color="#12335E" />
      </TouchableOpacity>
      <View style={styles.containerFiltros}>
        {abrirCalendario ? (
          <RNDateTimePicker
            testID="dateTimePicker"
            value={new Date()}
            mode={"date"}
            is24Hour={true}
            onChange={onChange}
            timeZoneName={"America/Cuiaba"}
          />
        ) : null}
        <View style={styles.containerFiltro}>
          <DropDown
            data={categorias}
            name="categoria"
            textoDropdown="Selecione uma categoria"
            handleInputChange={(field, value, iconName) => {
              handleInputChange(field, value, iconName);
            }}
            renderItem={(item, isSelected) => (
              <View style={styles.dropdownItemStyle}>
                {renderIcone(item.icone)}
                <Text
                  style={{
                    color: theme.colors.bluePrimary,
                    fontFamily: theme.fontFamily.raleway.semiBold,
                    backgroundColor: item.color,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 20,
                    textTransform: "capitalize",
                  }}
                >
                  {item.nome}
                </Text>
              </View>
            )}
            renderButton={(item, isSelected) => (
              <View style={styles.dropdownItemStyle}>
                {renderIcone(item.icone)}
                <Text
                  style={{
                    color: theme.colors.bluePrimary,
                    fontFamily: theme.fontFamily.raleway.semiBold,
                    backgroundColor: item.color,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 20,
                    textTransform: "capitalize",
                  }}
                >
                  {item.nome}
                </Text>
              </View>
            )}
            getValue={(item) => item.nome}
            getIcone={(item) => item.icone}
          />
        </View>
        <View style={styles.containerFiltro}>
          <TouchableOpacity
            style={styles.containerCalendario}
            onPress={() => handleAbrirCalendario("dataInicial")}
          >
            <TextInput
              style={styles.input}
              placeholder="Selecione a data inicial"
              value={
                formData?.dataInicial
                  ? formatarData(formData.dataInicial?.toString())
                  : ""
              }
              editable={false}
            />
            <View style={styles.buttonCalendario}>
              <AntDesign name="calendar" size={26} color="#12335E" />
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.containerFiltro}>
          <TouchableOpacity
            style={styles.containerCalendario}
            onPress={() => handleAbrirCalendario("dataFinal")}
          >
            <TextInput
              style={styles.input}
              placeholder="Selecione a data final"
              editable={false}
              value={
                formData?.dataFinal
                  ? formatarData(formData.dataFinal?.toString())
                  : ""
              }
            />
            <View style={styles.buttonCalendario}>
              <AntDesign name="calendar" size={26} color="#12335E" />
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.containerButton}>
          <Button
            text="Buscar"
            onPress={() => {
              handleButtonBuscar();
            }}
          />
        </View>
      </View>
    </View>
  );
}
