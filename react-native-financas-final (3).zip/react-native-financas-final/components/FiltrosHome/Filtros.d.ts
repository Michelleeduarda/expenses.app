interface FiltrosProps {
  handleInputChange: (field: string, value: string, icone?: string) => void;
  handleFecharFiltro: () => void;
  onChange: (event: DateTimePickerEvent, selectedDate?: Date) => void;
  fetcherFiltrarFinancas: () => void;
  handleAbrirCalendario: (tipo: string) => void;
  setFiltrado: React.Dispatch<React.SetStateAction<boolean>>;
  abrirCalendario: boolean;
  formData: FormFiltrosProps | undefined;
  dataType: string;
}

interface FormFiltrosProps {
  categoria?: string;
  dataInicial?: Date | null;
  dataFinal?: Date | null;
}
