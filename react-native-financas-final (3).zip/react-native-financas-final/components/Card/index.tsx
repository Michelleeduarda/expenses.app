import { View, Text } from "react-native";

import { styles } from "./styles";
import { IconeEntradaSaida } from "@/assets/icon/icone-entrada-saida";

export function Card({ tipo, titulo, valor }: CardProps) {
  return (
    <View style={styles.container}>
      <View
        style={[
          styles.containerIcone,
          tipo === "entrada"
            ? styles.containerIconeEntrada
            : styles.containerIconeSaida,
        ]}
      >
        <IconeEntradaSaida />
      </View>
      <Text style={styles.titulo}>{titulo}</Text>
      <Text style={styles.valor}>R$ {valor}</Text>
    </View>
  );
}
