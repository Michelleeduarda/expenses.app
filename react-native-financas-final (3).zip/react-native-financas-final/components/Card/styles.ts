import { theme } from "@/constants";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    width: "50%",
    borderRadius: 20,
    paddingVertical: 15,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.colors.white,
    elevation: 10,
  },
  containerIcone: {
    width: 50,
    height: 50,
    borderRadius: 100,
    alignItems: "center",
    justifyContent: "center",
  },
  containerIconeEntrada: {
    backgroundColor: "rgba(47, 180, 0, 0.2)",
  },
  containerIconeSaida: {
    backgroundColor: "rgba(233, 24, 24, 0.2)",
  },
  titulo: {
    fontSize: 16,
    fontFamily: theme.fontFamily.raleway.semiBold,
    color: theme.colors.bluePrimary,
    marginTop: 10,
  },
  valor: {
    fontSize: 20,
    fontFamily: theme.fontFamily.raleway.bold,
    color: theme.colors.bluePrimary,
  },
});
