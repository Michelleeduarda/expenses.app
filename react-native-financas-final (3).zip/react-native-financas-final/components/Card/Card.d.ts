interface CardProps {
  tipo: string;
  valor: string;
  titulo: string;
}
