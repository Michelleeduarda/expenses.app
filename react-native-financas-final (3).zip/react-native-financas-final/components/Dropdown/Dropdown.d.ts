interface DropdownProps<T> {
  data: T[];
  value?: string;
  name: string;
  textoDropdown: string;
  handleInputChange: (field: string, value: string, iconName: string) => void;
  renderItem: (item: T, isSelected: boolean) => React.ReactNode;
  renderButton: (item: T, isSelected: boolean) => React.ReactNode;
  getValue: (item: T) => string;
  getIcone: (item: T) => string;
}
