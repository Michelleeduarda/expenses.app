import React from "react";
import { View, Text } from "react-native";
import SelectDropdown from "react-native-select-dropdown";
import { Feather } from "@expo/vector-icons";
import { styles } from "./styles";

interface DropdownProps<T> {
  data: T[];
  value?: string;
  name: string;
  textoDropdown: string;
  handleInputChange: (field: string, value: string, iconName: string) => void;
  renderItem: (item: T, isSelected: boolean) => React.ReactNode;
  renderButton: (item: T, isSelected: boolean) => React.ReactNode;
  getValue: (item: T) => string;
  getIcone: (item: T) => string;
}

export function DropDown<T>({
  data,
  value,
  name,
  textoDropdown,
  handleInputChange,
  renderItem,
  renderButton,
  getValue,
  getIcone,
}: DropdownProps<T>) {
  return (
    <>
      <SelectDropdown
        data={data}
        defaultValue={data.find((item) => getValue(item) === value)}
        statusBarTranslucent={true}
        onSelect={(selectedItem: T) => {
          handleInputChange(
            name,
            getValue(selectedItem),
            getIcone(selectedItem)
          );
        }}
        renderButton={(selectedItem: T, isOpened: boolean) => {
          return (
            <View style={styles.dropdownButtonStyle}>
              <Text style={styles.dropdownButtonTxtStyle}>
                {selectedItem
                  ? renderButton(selectedItem, isOpened)
                  : textoDropdown}
              </Text>
              <Feather
                name={isOpened ? "chevron-up" : "chevron-down"}
                style={styles.dropdownButtonArrowStyle}
              />
            </View>
          );
        }}
        renderItem={(item: T, index: number, isSelected: boolean) => {
          return (
            <View
              style={{
                ...styles.dropdownItemStyle,
                ...(isSelected && { backgroundColor: "#EBF1FC" }),
              }}
            >
              {renderItem(item, isSelected)}
            </View>
          );
        }}
        showsVerticalScrollIndicator={false}
        dropdownStyle={styles.dropdownMenuStyle}
      />
    </>
  );
}
