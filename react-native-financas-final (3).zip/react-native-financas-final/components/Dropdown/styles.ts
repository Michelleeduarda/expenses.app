import { StyleSheet } from "react-native";

import { theme } from "@/constants";

export const styles = StyleSheet.create({
  dropdownButtonStyle: {
    width: "100%",
    height: 50,
    backgroundColor: theme.colors.white,
    borderRadius: 5,
    paddingHorizontal: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    fontFamily: theme.fontFamily.raleway.medium,
    fontSize: 16,
    color: theme.colors.bluePrimary,
  },
  dropdownButtonTxtStyle: {
    flex: 1,
    fontSize: 16,
    fontFamily: theme.fontFamily.raleway.medium,
    color: theme.colors.bluePrimary,
  },
  dropdownButtonArrowStyle: {
    fontSize: 24,
    color: "#606060",
  },

  dropdownMenuStyle: {
    backgroundColor: "#ffffff",
    padding: 5,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
  },
  dropdownItemStyle: {
    width: "100%",
    flexDirection: "row",
    paddingHorizontal: 12,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 8,
  },
  dropdownItemTxtStyle: {
    flex: 1,
    fontSize: 16,
    fontFamily: theme.fontFamily.raleway.semiBold,
    color: theme.colors.bluePrimary,
  },
});
