import { theme } from "@/constants";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    backgroundColor: theme.colors.white,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  containerIcone: {
    width: 50,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.colors.blueWhiteLight,
    borderRadius: 10,
  },
  containerTextos: {
    width: "65%",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  containerTitulo: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    justifyContent: "space-between",
    paddingRight: 10,
  },
  titulo: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 16,
    color: theme.colors.bluePrimary,
    textTransform: "capitalize",
  },
  containerTipo: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  containerTipoSaida: {
    backgroundColor: "rgba(233, 24, 24, 0.1)",
  },
  containerTipoEntrada: {
    backgroundColor: "rgba(47, 180, 0, 0.1)",
  },
  tipo: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 14,
    textTransform: "capitalize",
  },
  tipoSaida: {
    color: theme.colors.redDark,
  },
  tipoEntrada: {
    color: theme.colors.greenDark,
  },
  descricao: {
    fontFamily: theme.fontFamily.raleway.regular,
    fontSize: 16,
    color: theme.colors.blueSecundary,
  },
  containerValor: {
    alignItems: "flex-end",
    justifyContent: "center",
    gap: 5,
  },
  valor: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 16,
  },
  valorSaida: {
    color: theme.colors.redDark,
  },
  valorEntrada: {
    color: theme.colors.greenDark,
  },
  data: {
    fontFamily: theme.fontFamily.raleway.regular,
    fontSize: 14,
    color: theme.colors.blueSecundary,
  },
});
