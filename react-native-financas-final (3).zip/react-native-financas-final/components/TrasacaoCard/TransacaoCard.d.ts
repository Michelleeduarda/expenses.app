interface TransacaoCardProps {
  id: string;
  categoria: string;
  data: string;
  descricao: string;
  valor: number;
  tipo: string;
  icone?: string;
}
