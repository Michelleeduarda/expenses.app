import { View, Text } from "react-native";

import { formatarDataSemAno } from "@/helper/formatarData";
import { icones } from "@/data";

import { styles } from "./styles";

export function TransacaoCard({
  id,
  categoria,
  descricao,
  valor,
  tipo,
  data,
  icone,
}: TransacaoCardProps) {
  const renderIcone = (icone: string) => icones[icone];
  return (
    <View style={styles.container}>
      <View style={styles.containerIcone}>{renderIcone(icone!)}</View>
      <View style={styles.containerTextos}>
        <View style={styles.containerTitulo}>
          <Text style={styles.titulo}>{categoria}</Text>
          <View
            style={[
              styles.containerTipo,
              tipo.toLowerCase() === "entrada"
                ? styles.containerTipoEntrada
                : styles.containerTipoSaida,
            ]}
          >
            <Text
              style={[
                styles.tipo,
                tipo.toLowerCase() === "entrada"
                  ? styles.tipoEntrada
                  : styles.tipoSaida,
              ]}
            >
              {tipo}
            </Text>
          </View>
        </View>
        <Text style={styles.descricao}>{descricao}</Text>
      </View>
      <View style={styles.containerValor}>
        <Text
          style={[
            styles.valor,
            tipo.toLowerCase() === "entrada"
              ? styles.valorEntrada
              : styles.valorSaida,
          ]}
        >
          R$ {valor}
        </Text>
        <Text style={styles.data}>{formatarDataSemAno(data)}</Text>
      </View>
    </View>
  );
}
