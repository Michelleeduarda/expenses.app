import {
  ActivityIndicator,
  FlatList,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { formatarDataMaisUm } from "@/helper/formatarData";

import { FiltrosHome } from "../FiltrosHome";
import { TransacaoCard } from "../TrasacaoCard";

import { Ionicons } from "@expo/vector-icons";

import { styles } from "./styles";

export function Transacoes({
  data,
  abrirCalendario,
  exibirFiltro,
  handleInputChange,
  handleAbrirCalendario,
  handleExibirFiltro,
  handleFecharFiltro,
  onChange,
  fetcherTodasFinancas,
  fetcherFiltrarFinancas,
  formData,
  dataType,
  carregando,
}: TransacoesProps) {
  const renderTransacao = ({ item }: { item: TransacaoProps }) => (
    <TransacaoCard
      id={item.id}
      categoria={item.categoria}
      descricao={item.descricao}
      valor={item.valor}
      tipo={item.tipo}
      data={item.data}
      icone={item.icone}
    />
  );

  const renderItem = ({ item }: { item: TransacoesPorData }) => (
    <View>
      <Text style={styles.dataTransacao}>{formatarDataMaisUm(item.data)}</Text>
      <View style={styles.containerTransacoes}>
        <FlatList
          data={item.transacoes}
          renderItem={renderTransacao}
          keyExtractor={(transacao) => transacao.id}
        />
      </View>
    </View>
  );

  return (
    <>
      <View style={styles.container}>
        <SafeAreaView style={styles.containerFlatlist}>
          {carregando ? (
            <ActivityIndicator color={"#12335E"} size={40} />
          ) : (
            <FlatList
              data={data}
              style={styles.flatList}
              renderItem={renderItem}
              keyExtractor={(item) => item.data}
              showsVerticalScrollIndicator={false}
            />
          )}
        </SafeAreaView>
      </View>
    </>
  );
}
