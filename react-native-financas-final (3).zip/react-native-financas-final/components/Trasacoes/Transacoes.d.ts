interface TransacoesProps {
  data: TransacoesPorData[];
  exibirFiltro: boolean;
  abrirCalendario: boolean;
  handleAbrirCalendario: (tipo: string) => void;
  handleExibirFiltro: () => void;
  handleFecharFiltro: () => void;
  handleInputChange: (field: string, value: string, icone?: string) => void;
  onChange: (event: DateTimePickerEvent, selectedDate?: Date) => void;
  fetcherTodasFinancas: () => void;
  fetcherFiltrarFinancas: () => void;
  formData: FormFiltrosProps | undefined;
  dataType: string;
  carregando: boolean;
}

interface FormFiltrosProps {
  categoria?: string;
  dataInicial?: Date | null;
  dataFinal?: Date | null;
}
interface TransacaoProps {
  id: string;
  categoria: string;
  data: string;
  descricao: string;
  valor: number;
  tipo: string;
  usuarioId: string;
  icone: string;
}

interface TransacoesPorData {
  data: string;
  transacoes: TransacaoProps[];
}
