import { StyleSheet } from "react-native";

import { theme } from "@/constants";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    flexDirection: "column",
    paddingVertical: 10,
    paddingHorizontal: 20,
    gap: 10,
  },
  containerTransacoes: {
    width: "100%",
    backgroundColor: theme.colors.white,
    paddingVertical: 5,
    borderRadius: 10,
    marginBottom: 10,
  },
  dataTransacao: {
    fontSize: 14,
    fontFamily: theme.fontFamily.raleway.regular,
    color: theme.colors.bluePrimary,
    marginBottom: 5,
  },
  containerFiltro: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.colors.bluePrimary,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  containerFiltros: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
    position: "absolute",
    zIndex: 99,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  containerFlatlist: {
    width: "100%",
    marginBottom: 10,
    alignItems: "center",
    justifyContent: "flex-end",
  },
  flatList: {
    height: "42%",
    width: "100%",
  },
});
