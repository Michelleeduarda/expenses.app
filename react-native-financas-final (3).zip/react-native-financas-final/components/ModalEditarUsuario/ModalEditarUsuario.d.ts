interface ModalEditarUsuarioProps {
  fecharModal: () => void;
  handleAlterarSenha: (value: string) => void;
  handleAlterarNome: (value: string) => void;
  handleRemoverImagem: () => void;
  handleSubmit: () => void;
  trocarFotoPerfil: () => Promise<void>;
  nomeDefaultValue: string;
  isKeyboardVisible: boolean;
  imagem: string | null;
  nomeImagem: string | null | undefined;
  mensagemAlert: string;
  tipoAlert: string;
  abrirAlert: boolean;
  carregando: boolean;
  senha: string;
}
