import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  Image,
  ActivityIndicator,
} from "react-native";

import { Alert } from "../Alert";

import { Ionicons } from "@expo/vector-icons";

import { styles } from "./styles";

export function ModalEditarUsuario({
  fecharModal,
  handleAlterarSenha,
  handleAlterarNome,
  handleRemoverImagem,
  handleSubmit,
  trocarFotoPerfil,
  nomeDefaultValue,
  isKeyboardVisible,
  imagem,
  nomeImagem,
  abrirAlert,
  mensagemAlert,
  tipoAlert,
  carregando,
  senha,
}: ModalEditarUsuarioProps) {
  return (
    <View style={styles.container}>
      <View
        style={[
          styles.containerInterno,
          isKeyboardVisible ? styles.containerInternoKeyboard : null,
        ]}
      >
        <View style={styles.containerTitulo}>
          <Text style={styles.titulo}>Editar Perfil</Text>
          <TouchableOpacity onPress={fecharModal}>
            <Ionicons name="close" size={28} color="#525252" />
          </TouchableOpacity>
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Editar nome</Text>
          <TextInput
            style={styles.input}
            defaultValue={nomeDefaultValue}
            placeholder="Digite seu nome"
            onChangeText={handleAlterarNome}
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Alterar senha</Text>
          <TextInput
            style={styles.input}
            secureTextEntry={true}
            placeholder="********"
            value={senha}
            onChangeText={handleAlterarSenha}
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Alterar foto</Text>
          {imagem ? (
            <View style={styles.containerUpload}>
              <View style={styles.containerImagem}>
                <Image source={{ uri: imagem }} style={styles.imagem} />
                <View style={styles.containerTexto}>
                  <Text style={styles.textoImagem}>{nomeImagem}</Text>
                </View>
              </View>
              <TouchableOpacity onPress={handleRemoverImagem}>
                <Ionicons name="close" size={24} color="#12335E" />
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={styles.button} onPress={trocarFotoPerfil}>
              <Text style={styles.textoButton}>Selecionar imagem</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.containerInput}>
          {abrirAlert && <Alert tipo={tipoAlert} mensagem={mensagemAlert} />}
          <TouchableOpacity style={styles.buttonAlterar} onPress={handleSubmit}>
            {carregando ? (
              <ActivityIndicator size={26} color={"#fff"} />
            ) : (
              <Text style={styles.textoButtonAlterar}>Salvar</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
