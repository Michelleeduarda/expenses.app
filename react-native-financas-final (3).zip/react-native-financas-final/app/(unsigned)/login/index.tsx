import React, { useEffect, useState } from "react";
import { View, Text, TextInput, Keyboard, Image } from "react-native";
import { Link, useRouter } from "expo-router";

import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/firebase/config";

import Button from "@/components/Button";
import { Alert } from "@/components/Alert";

import { ImagemLogin } from "@/assets/images/imagem-login";

import { styles } from "./style";

export default function Login() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const [abrirAlerta, setAbrirAlerta] = useState(false);
  const [mensagemAlerta, setMensagemAlerta] = useState("");
  const [tipoAlerta, setTipoAlerta] = useState("");

  const [carregando, setCarregando] = useState(false);

  const [isKeyboardVisible, setKeyboardVisible] = useState(false);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        setKeyboardVisible(true);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => {
        setKeyboardVisible(false);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  async function loginUsuario() {
    if (!email || !senha) {
      return;
    }

    setCarregando(true);

    try {
      await signInWithEmailAndPassword(auth, email, senha);

      setCarregando(false);

      router.replace("/home");
    } catch (e) {
      setMensagemAlerta("Email ou senha inválidos");
      setTipoAlerta("erro");
      setAbrirAlerta(true);

      setCarregando(false);

      setTimeout(() => {
        setAbrirAlerta(false);
      }, 5000);

      console.log(e);
    }
  }

  return (
    <View style={styles.container}>
      <ImagemLogin />
      <View style={styles.containerInterno}>
        {isKeyboardVisible ? null : (
          <Image source={require("@/assets/images/logo.png")} />
        )}
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            style={styles.input}
            placeholder="Digite seu email"
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Senha</Text>
          <TextInput
            value={senha}
            onChangeText={setSenha}
            style={styles.input}
            placeholder="Digite sua senha"
            secureTextEntry={true}
          />
        </View>
        {abrirAlerta && <Alert mensagem={mensagemAlerta} tipo={tipoAlerta} />}
        <View style={styles.containerButton}>
          <Button
            text="Entrar"
            onPress={loginUsuario}
            carregando={carregando}
          />
        </View>
        <View style={styles.containerTextoCadastro}>
          <Link href={"/cadastro"}>
            <Text style={styles.textoCadastro}>
              Não tem conta?{" "}
              <Text style={styles.textoCadastroDestaque}>Cadastre-se</Text>
            </Text>
          </Link>
        </View>
      </View>
    </View>
  );
}
