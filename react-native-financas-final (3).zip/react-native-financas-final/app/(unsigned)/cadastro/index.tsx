import { View, Text, TextInput, Keyboard, Image } from "react-native";
import React, { useEffect, useState } from "react";
import { Link, useRouter } from "expo-router";

import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth } from "@/firebase/config";

import Button from "@/components/Button";
import { ImagemCadastro } from "@/assets/images/imagem-cadastro";

import { styles } from "./style";
import { SnackBar } from "@/components/SnackBar";

export default function Cadastro() {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");

  const [abrirSnackBar, setAbrirSnackBar] = useState(false);
  const [mensagemSnackBar, setMensagemSnackBar] = useState("");
  const [tipoSnackBar, setTipoSnackBar] = useState("");

  const [carregando, setCarregando] = useState(false);

  const router = useRouter();

  const [isKeyboardVisible, setKeyboardVisible] = useState(false);

  async function cadastrarUsuario() {
    if (!nome || !email || !senha) {
      return;
    }

    if (senha.length < 6) {
      setMensagemSnackBar("A senha deve ter no mínimo 6 caracteres");
      setTipoSnackBar("erro");
      setAbrirSnackBar(true);

      setTimeout(() => {
        setAbrirSnackBar(false);
      }, 5000);

      return;
    }

    if (senha !== confirmarSenha) {
      setMensagemSnackBar("As senhas precisam ser iguais");
      setTipoSnackBar("erro");
      setAbrirSnackBar(true);

      setTimeout(() => {
        setAbrirSnackBar(false);
      }, 5000);

      return;
    }

    setCarregando(true);

    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, senha);

      await updateProfile(user, {
        displayName: nome,
      });

      if (user) {
        setNome("");
        setEmail("");
        setSenha("");
        setConfirmarSenha("");

        setMensagemSnackBar("Usuário criado com sucesso. Realize seu login");
        setTipoSnackBar("sucesso");
        setAbrirSnackBar(true);

        setCarregando(false);

        setTimeout(() => {
          setAbrirSnackBar(false);
          router.navigate("/login");
        }, 5000);
      }
    } catch (e) {
      setMensagemSnackBar(
        "Não foi possível criar seu cadastro. Tente novamente"
      );
      setTipoSnackBar("erro");
      setAbrirSnackBar(true);

      setCarregando(false);

      setTimeout(() => {
        setAbrirSnackBar(false);
      }, 5000);

      console.log(e);
    }
  }

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        setKeyboardVisible(true);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => {
        setKeyboardVisible(false);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  return (
    <View style={styles.container}>
      <ImagemCadastro />
      {abrirSnackBar && (
        <SnackBar
          mensagem={mensagemSnackBar}
          tipo={tipoSnackBar}
          onClose={() => setAbrirSnackBar(false)}
        />
      )}
      <View style={styles.containerInterno}>
        {isKeyboardVisible ? null : (
          <Image source={require("@/assets/images/logo.png")} />
        )}
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Nome</Text>
          <TextInput
            value={nome}
            onChangeText={setNome}
            style={styles.input}
            placeholder="Digite seu nome"
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            style={styles.input}
            placeholder="Digite seu email"
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Senha</Text>
          <TextInput
            value={senha}
            onChangeText={setSenha}
            style={styles.input}
            placeholder="Digite sua senha"
            secureTextEntry={true}
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Confirmar senha</Text>
          <TextInput
            value={confirmarSenha}
            onChangeText={setConfirmarSenha}
            style={styles.input}
            placeholder="Digite sua senha novamente"
            secureTextEntry={true}
          />
        </View>
        <View style={styles.containerButton}>
          <Button
            text="Cadastrar"
            onPress={cadastrarUsuario}
            carregando={carregando}
          />
        </View>
        <View style={styles.containerTextoCadastro}>
          <Link href={"/login"}>
            <Text style={styles.textoCadastro}>
              Já tem conta?{" "}
              <Text style={styles.textoCadastroDestaque}>Login</Text>
            </Text>
          </Link>
        </View>
      </View>
    </View>
  );
}
