import { theme } from "@/constants";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    backgroundColor: theme.colors.white,
  },
  containerInterno: {
    alignItems: "center",
    width: "90%",
  },
  containerInput: {
    width: "100%",
    alignItems: "flex-start",
    flexDirection: "column",
    justifyContent: "center",
    marginBottom: 10,
    gap: 5,
  },
  containerButton: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
  },
  textoInput: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 16,
    color: theme.colors.bluePrimary,
  },
  input: {
    width: "100%",
    height: 50,
    borderRadius: 10,
    paddingLeft: 8,
    fontSize: 18,
    color: theme.colors.bluePrimary,
    backgroundColor: theme.colors.blueWhiteLight,
  },
  containerTextoCadastro: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
  },
  textoCadastro: {
    fontFamily: theme.fontFamily.raleway.medium,
    color: theme.colors.bluePrimary,
    fontSize: 16,
  },
  textoCadastroDestaque: {
    fontFamily: theme.fontFamily.raleway.bold,
    color: theme.colors.bluePrimary,
    fontSize: 16,
    textDecorationLine: "underline",
  },
});
