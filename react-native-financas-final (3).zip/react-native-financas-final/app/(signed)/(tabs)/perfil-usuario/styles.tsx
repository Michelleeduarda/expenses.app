import { StyleSheet } from "react-native";

import { theme } from "@/constants";

export const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    height: "100%",
    backgroundColor: theme.colors.blueWhiteLight,
  },
  containerPerfilUsuario: {
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  containerHeader: {
    width: "95%",
    height: 210,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 15,
    backgroundColor: theme.colors.bluePrimary,
  },
  containerImagemPerfil: {
    height: 75,
    width: 75,
    borderRadius: 100,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.colors.blueWhiteLight,
  },
  imagemPerfil: {
    width: "100%",
    height: "100%",
    borderRadius: 100,
  },
  containerNomeUsuario: {
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 5,
    gap: 8,
  },
  nomeUsuario: {
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 24,
    color: theme.colors.white,
  },
  containerInformacoes: {
    alignItems: "center",
    backgroundColor: theme.colors.white,
    paddingVertical: 35,
    width: "95%",
    marginTop: -40,
    borderTopLeftRadius: 40,
    borderBottomRightRadius: 40,
    borderRadius: 5,
  },
  containerInput: {
    width: "90%",
    alignItems: "flex-start",
    flexDirection: "column",
    justifyContent: "center",
    marginBottom: 10,
    gap: 5,
  },
  input: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 16,
    color: theme.colors.bluePrimary,
    width: "100%",
    height: 50,
    borderRadius: 10,
    backgroundColor: theme.colors.blueWhiteLight,
    paddingLeft: 8,
  },
  inputSenha: {
    width: "90%",
  },
  containerInputIcone: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    backgroundColor: theme.colors.blueWhiteLight,
    width: "100%",
    height: 50,
    borderRadius: 10,
  },
  textoInput: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 14,
    color: theme.colors.bluePrimary,
  },
  containerSair: {
    width: "90%",
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    paddingLeft: 5,
    marginTop: 10,
  },
  containerIcones: {
    flexDirection: "row",
    gap: 5,
  },
  textoSair: {
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 16,
    color: theme.colors.bluePrimary,
  },
});
