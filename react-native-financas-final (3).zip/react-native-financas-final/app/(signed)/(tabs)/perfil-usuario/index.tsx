import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  Keyboard,
} from "react-native";
import React, { useEffect, useState } from "react";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";

import { updatePassword, updateProfile } from "firebase/auth";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { auth, storage } from "@/firebase/config";

import { useAuthenticate } from "@/hooks/useAuthenticate";
import { transformaImagemParaBlob } from "@/helper/transformaImagemParaBlob";
import { formatarData } from "@/helper/formatarData";

import { ModalEditarUsuario } from "@/components/ModalEditarUsuario";

import { FontAwesome } from "@expo/vector-icons";
import { MaterialIcons } from "@expo/vector-icons";
import { Ionicons } from "@expo/vector-icons";
import { Entypo } from "@expo/vector-icons";

import { ImagemPerfilUsuario } from "@/assets/images/imagem-perfil-usuario";

import { styles } from "./styles";

export default function PerfilUsuario() {
  const [senha, setSenha] = useState("");
  const [nome, setNome] = useState("");

  const [imagem, setImagem] = useState<string | null>(null);
  const [nomeImagem, setNomeImagem] = useState<string | null | undefined>(null);

  const [abrirModal, setAbrirModal] = useState<boolean>(false);
  const [abrirAlert, setAbrirAlert] = useState<boolean>(false);
  const [mensagemAlert, setMensagemAlert] = useState<string>("");
  const [tipoAlert, setTipoAlert] = useState<string>("");

  const [isKeyboardVisible, setIsKeyboardVisible] = useState<boolean>(false);
  const [carregando, setCarregando] = useState<boolean>(false);

  const router = useRouter();
  const { user } = useAuthenticate();

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        setIsKeyboardVisible(true);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => {
        setIsKeyboardVisible(false);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  if (!user) return null;

  const handleSignOut = () => {
    auth.signOut();
    router.replace("/login");
  };

  const handleAlterarSenha = (value: string) => {
    setSenha(value);
  };

  const handleAlterarNome = (value: string) => {
    setNome(value);
  };

  const handleRemoverImagem = () => {
    setImagem(null);
    setNomeImagem(null);
  };

  const handleSubmit = async () => {
    if (nome !== user?.displayName) {
      await trocarNome();
    }

    if (senha !== "") {
      await trocarSenha();
    }

    if (imagem !== null) {
      await uploadImagem();
    }
  };

  async function trocarSenha() {
    if (!senha) {
      return;
    }

    if (senha.length < 6) {
      return;
    }

    setCarregando(true);

    try {
      await updatePassword(user!, senha);

      setSenha("");

      setCarregando(false);

      setMensagemAlert("Senha alterada com sucesso");
      setTipoAlert("sucesso");
      setAbrirAlert(true);

      setTimeout(() => {
        setAbrirAlert(false);
      }, 5000);
    } catch (e) {
      setCarregando(false);

      setMensagemAlert("Ocorreu um erro ao altualizar senha");
      setTipoAlert("erro");
      setAbrirAlert(true);

      setTimeout(() => {
        setAbrirAlert(false);
      }, 5000);

      console.log(e);
    }
  }

  async function trocarNome() {
    if (!nome) {
      return;
    }

    setCarregando(true);

    try {
      await updateProfile(user!, {
        displayName: nome,
      });

      setCarregando(false);

      setMensagemAlert("Nome alterado com sucesso");
      setTipoAlert("sucesso");
      setAbrirAlert(true);

      setTimeout(() => {
        setAbrirAlert(false);
      }, 5000);
    } catch (e) {
      console.log(e);

      setCarregando(false);

      setMensagemAlert("Ocorreu um erro ao altualizar nome");
      setTipoAlert("erro");
      setAbrirAlert(true);

      setTimeout(() => {
        setAbrirAlert(false);
      }, 5000);
    }
  }

  async function trocarFotoPerfil() {
    let imagem = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
      base64: true,
    });

    if (!imagem.assets) {
      return;
    }

    const { uri, fileName } = imagem.assets[0];

    setImagem(uri);
    setNomeImagem(fileName);
  }

  const uploadImagem = async () => {
    if (imagem === null) return;

    setCarregando(true);

    const fileRef = ref(storage, user!.uid + "-" + imagem);
    try {
      const blob = await transformaImagemParaBlob(imagem);
      await uploadBytes(fileRef, blob);
      const url = await getDownloadURL(fileRef);
      await updateProfile(user!, {
        photoURL: url,
      });

      setCarregando(false);

      setMensagemAlert("Imagem alterada com sucesso");
      setTipoAlert("sucesso");
      setAbrirAlert(true);

      setImagem(null);
      setNomeImagem(null);

      setTimeout(() => {
        setAbrirAlert(false);
      }, 5000);
    } catch (e) {
      console.log(e);

      setCarregando(false);

      setMensagemAlert("Ocorreu um erro ao atualizar imagem");
      setTipoAlert("erro");
      setAbrirAlert(true);

      setTimeout(() => {
        setAbrirAlert(false);
      }, 5000);
    }
  };

  return (
    <View style={styles.container}>
      <ImagemPerfilUsuario />
      {abrirModal && (
        <ModalEditarUsuario
          fecharModal={() => setAbrirModal(false)}
          handleAlterarSenha={handleAlterarSenha}
          handleAlterarNome={handleAlterarNome}
          handleRemoverImagem={handleRemoverImagem}
          handleSubmit={handleSubmit}
          nomeDefaultValue={user.displayName!}
          trocarFotoPerfil={trocarFotoPerfil}
          isKeyboardVisible={isKeyboardVisible}
          imagem={imagem}
          nomeImagem={nomeImagem}
          tipoAlert={tipoAlert}
          mensagemAlert={mensagemAlert}
          abrirAlert={abrirAlert}
          carregando={carregando}
          senha={senha}
        />
      )}
      <View style={styles.containerPerfilUsuario}>
        <View style={styles.containerHeader}>
          <View style={styles.containerImagemPerfil}>
            {user.photoURL ? (
              <Image
                source={{ uri: user.photoURL }}
                style={styles.imagemPerfil}
              />
            ) : (
              <FontAwesome name="user" size={24} color="#12335E" />
            )}
          </View>
          <TouchableOpacity
            style={styles.containerNomeUsuario}
            onPress={() => setAbrirModal(true)}
          >
            <Text style={styles.nomeUsuario}>{user.displayName}</Text>
            <MaterialIcons name="edit" size={24} color="#ffffff" />
          </TouchableOpacity>
        </View>
        <View style={styles.containerInformacoes}>
          <View style={styles.containerInput}>
            <Text style={styles.textoInput}>Criação da conta em</Text>
            <TextInput
              style={styles.input}
              editable={false}
              value={formatarData(user?.metadata.creationTime!.toString())}
            />
          </View>
          <View style={styles.containerInput}>
            <Text style={styles.textoInput}>Email</Text>
            <TextInput
              style={styles.input}
              defaultValue={user?.email!}
              editable={false}
            />
          </View>
          <View style={styles.containerInput}>
            <Text style={styles.textoInput}>Senha</Text>
            <View style={styles.containerInputIcone}>
              <TextInput
                style={[styles.input, styles.inputSenha]}
                secureTextEntry={true}
                value={senha}
                placeholder="********"
                onChangeText={setSenha}
              />
              <TouchableOpacity onPress={() => setAbrirModal(true)}>
                <MaterialIcons name="edit" size={24} color="#12335E" />
              </TouchableOpacity>
            </View>
          </View>
          <TouchableOpacity
            style={styles.containerSair}
            onPress={handleSignOut}
          >
            <View style={styles.containerIcones}>
              <Ionicons name="exit-outline" size={24} color="#8B0000" />
              <Text style={styles.textoSair}>Sair</Text>
            </View>
            <Entypo name="chevron-small-right" size={24} color="#525252" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
