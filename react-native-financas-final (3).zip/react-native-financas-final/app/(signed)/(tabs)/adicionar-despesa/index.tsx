import React, { useState } from "react";
import { Text, TextInput, TouchableOpacity, View } from "react-native";
import RNDateTimePicker, {
  DateTimePickerEvent,
} from "@react-native-community/datetimepicker";

import { criandoFinanca } from "@/firebase/financa/criandoFinanca";
import { useAuthenticate } from "@/hooks/useAuthenticate";
import { formatarData } from "@/helper/formatarData";

import Button from "@/components/Button";
import { SnackBar } from "@/components/SnackBar";
import { DropDown } from "@/components/Dropdown";

import { ImagemAdicionarDespesa } from "@/assets/images/imagem-adicionar-despesa";

import { AntDesign } from "@expo/vector-icons";

import { categorias, icones, tipo } from "@/data";

import { theme } from "@/constants";
import { styles } from "./styles";

const templateForm = {
  categoria: "",
  data: null,
  descricao: "",
  valor: 0,
  tipo: "",
  icone: "",
};

interface AdicionarDespesasProps<T> {
  initialValues?: T;
}

interface FormDataProps {
  categoria: string;
  data: Date | null;
  descricao: string;
  valor: number;
  tipo: string;
  icone: string;
}

interface Icones {
  [key: string]: JSX.Element;
}

export default function AdicionarDespesa() {
  const [formData, setFormData] = useState<FormDataProps>(templateForm);
  const [date, setDate] = useState(new Date());

  const [abrirSnackBar, setAbrirSnackBar] = useState<boolean>(false);
  const [mensagemSnackBar, setMensagemSnackBar] = useState<string>("");
  const [tipoSnackBar, setTipoSnackBar] = useState<string>("");

  const [abrirCalendario, setAbrirCalendario] = useState<boolean>(false);
  const [carregando, setCarregando] = useState<boolean>(false);

  const { user } = useAuthenticate();

  const handleInputChange = (field: string, value: string, icone?: string) => {
    setFormData((prevState) => ({
      ...prevState,
      [field]: value,
      ...(field === "categoria" && { icone: icone || prevState.icone }),
    }));
  };

  const onChange = (event: DateTimePickerEvent, selectedDate?: Date) => {
    if (selectedDate) {
      const novaData = new Date(selectedDate);

      setAbrirCalendario(false);

      setDate(selectedDate);

      setFormData((prevState) => ({
        ...prevState,
        data: novaData,
      }));
    }
  };

  const handleSubmit = async () => {
    if (
      formData.categoria === "" ||
      formData.descricao === "" ||
      formData.valor === 0 ||
      formData.tipo === ""
    )
      return;

    setCarregando(true);

    try {
      await criandoFinanca(
        formData.categoria,
        formData.descricao,
        Number(formData.valor),
        formData.tipo.toUpperCase(),
        formData.data!.toString(),
        formData.icone, // Salvar apenas o ícone da categoria
        user!.uid
      );

      setFormData({
        ...formData,
        descricao: "",
        valor: 0,
      });

      setCarregando(false);

      setMensagemSnackBar("Despesa adicionada com sucesso");
      setTipoSnackBar("sucesso");
      setAbrirSnackBar(true);

      setTimeout(() => {
        setAbrirSnackBar(false);
      }, 5000);
    } catch (error) {
      setCarregando(false);

      setMensagemSnackBar("Não foi possível adicionar a despesa");
      setTipoSnackBar("erro");
      setAbrirSnackBar(true);

      setTimeout(() => {
        setAbrirSnackBar(false);
      }, 5000);

      console.log(error);
    }
  };

  const renderIcone = (icone: string) => icones[icone];

  return (
    <View style={styles.container}>
      <View style={styles.containerImagem}>
        <ImagemAdicionarDespesa />
      </View>
      {abrirSnackBar && (
        <SnackBar
          mensagem={mensagemSnackBar}
          tipo={tipoSnackBar}
          onClose={() => setAbrirSnackBar(false)}
        />
      )}
      {abrirCalendario ? (
        <RNDateTimePicker
          testID="dateTimePicker"
          value={date}
          mode={"date"}
          is24Hour={true}
          onChange={onChange}
          timeZoneName={"America/Cuiaba"}
          maximumDate={new Date(2024, 6, 20)}
        />
      ) : null}
      <View style={styles.containerInterno}>
        <Text style={styles.titulo}>Nova Despesa</Text>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Selecionar categoria</Text>
          <DropDown
            data={categorias}
            name="categoria"
            textoDropdown="Selecione uma categoria"
            handleInputChange={(field, value, iconName) => {
              handleInputChange(field, value, iconName);
            }}
            renderItem={(item, isSelected) => (
              <View style={styles.dropdownItemStyle}>
                {renderIcone(item.icone)}
                <Text
                  style={{
                    color: theme.colors.bluePrimary,
                    fontFamily: theme.fontFamily.raleway.semiBold,
                    backgroundColor: item.color,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 20,
                    textTransform: "capitalize",
                  }}
                >
                  {item.nome}
                </Text>
              </View>
            )}
            renderButton={(item, isSelected) => (
              <View style={styles.dropdownItemStyle}>
                {renderIcone(item.icone)}
                <Text
                  style={{
                    color: theme.colors.bluePrimary,
                    fontFamily: theme.fontFamily.raleway.semiBold,
                    backgroundColor: item.color,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 20,
                    textTransform: "capitalize",
                  }}
                >
                  {item.nome}
                </Text>
              </View>
            )}
            getValue={(item) => item.nome}
            getIcone={(item) => item.icone}
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Data</Text>
          <TouchableOpacity
            style={styles.containerCalendario}
            onPress={() => setAbrirCalendario(true)}
          >
            <TextInput
              style={styles.input}
              value={
                formData.data ? formatarData(formData.data.toString()) : ""
              }
              placeholder="Selecione uma data"
              editable={false}
            />
            <View style={styles.buttonCalendario}>
              <AntDesign name="calendar" size={26} color="#12335E" />
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Descrição</Text>
          <TextInput
            style={styles.input}
            value={formData.descricao}
            placeholder="Digite uma descrição para sua despesa"
            onChangeText={(value) => handleInputChange("descricao", value)}
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Valor da despesa</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            value={
              formData.valor.toString() == "0" ? "" : formData.valor.toString()
            }
            placeholder="Digite uma valor para sua despesa"
            onChangeText={(value) => handleInputChange("valor", value)}
          />
        </View>
        <View style={styles.containerInput}>
          <Text style={styles.textoInput}>Tipo da despesa</Text>
          <DropDown
            data={tipo}
            name="tipo"
            textoDropdown="Selecione um tipo"
            handleInputChange={(field, value, icone) => {
              handleInputChange(field, value, icone);
            }}
            renderItem={(item, isSelected) => (
              <View style={styles.dropdownItemStyle}>
                {renderIcone(item.icone)}
                <Text
                  style={{
                    color: theme.colors.bluePrimary,
                    fontFamily: theme.fontFamily.raleway.semiBold,
                    backgroundColor: isSelected ? item.color : item.color,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 20,
                    textTransform: "capitalize",
                  }}
                >
                  {item.nome}
                </Text>
              </View>
            )}
            renderButton={(item, isSelected) => (
              <View style={styles.dropdownItemStyle}>
                {renderIcone(item.icone)}
                <Text
                  style={{
                    color: theme.colors.bluePrimary,
                    fontFamily: theme.fontFamily.raleway.semiBold,
                    backgroundColor: item.color,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 20,
                    textTransform: "capitalize",
                  }}
                >
                  {item.nome}
                </Text>
              </View>
            )}
            getValue={(item) => item.nome}
            getIcone={(item) => item.icone}
          />
        </View>
        <Button
          carregando={carregando}
          text="Adicionar"
          onPress={() => handleSubmit()}
        />
      </View>
    </View>
  );
}
