import { StyleSheet } from "react-native";
import { theme } from "@/constants";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    backgroundColor: theme.colors.blueWhiteLight,
  },
  containerInterno: {
    width: "90%",
    height: "100%",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  containerImagem: {
    width: "100%",
    position: "absolute",
  },
  titulo: {
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 30,
    color: theme.colors.bluePrimary,
    marginBottom: 15,
    marginTop: 30,
  },
  containerInput: {
    width: "100%",
    alignItems: "flex-start",
    flexDirection: "column",
    justifyContent: "center",
    marginBottom: 10,
    gap: 5,
  },
  containerCalendario: {
    width: "90%",
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: theme.colors.white,
    height: 50,
  },
  buttonCalendario: {
    backgroundColor: theme.colors.white,
    height: 50,
    width: 45,
    marginLeft: -10,
    alignItems: "center",
    justifyContent: "center",
    borderTopEndRadius: 10,
    borderBottomEndRadius: 10,
  },
  textoInput: {
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 14,
    color: theme.colors.bluePrimary,
  },
  input: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 16,
    color: theme.colors.bluePrimary,
    width: "100%",
    height: 50,
    borderRadius: 10,
    backgroundColor: theme.colors.white,
    paddingLeft: 8,
  },
  dropdownItemTxtStyle: {
    color: theme.colors.bluePrimary,
    fontFamily: theme.fontFamily.raleway.semiBold,
    textTransform: "capitalize",
  },
  dropdownItemStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    width: "100%",
    paddingHorizontal: 10,
    gap: 8,
  },
});
