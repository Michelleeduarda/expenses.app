interface AdicionarDespesasProps<T> {
  initialValues?: T;
}

interface FormDataProps {
  categoria: string;
  data: Date | null;
  descricao: string;
  valor: number;
  tipo: string;
  icone: string;
}

interface Icones {
  [key: string]: JSX.Element;
}
