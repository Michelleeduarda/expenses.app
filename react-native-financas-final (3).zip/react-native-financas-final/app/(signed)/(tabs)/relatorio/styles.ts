import { theme } from "@/constants";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    alignItems: "center",

    backgroundColor: theme.colors.blueWhiteLight,
  },
  containerImagem: {
    width: "100%",
    alignItems: "flex-end",
  },
  containerInterno: {
    width: "95%",
    alignItems: "flex-start",
    justifyContent: "center",
    paddingVertical: 20,
  },
  containerRelatorioAno: {
    width: "100%",
    paddingHorizontal: 10,
  },
  tituloRelatorio: {
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 26,
    color: theme.colors.bluePrimary,
    marginBottom: 15,
  },
  containerTotalizadores: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  tituloTotalizador: {
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 20,
    color: theme.colors.bluePrimary,
  },
  valorEntrada: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 20,
    color: theme.colors.greenDark,
  },
  valorSaida: {
    fontFamily: theme.fontFamily.raleway.medium,
    fontSize: 20,
    color: theme.colors.redDark,
  },
  containerGrafico: {
    width: "100%",
    alignItems: "flex-start",
    justifyContent: "center",
    flexDirection: "column",
    marginTop: 20,
    paddingHorizontal: 10,
  },
  containerCarregando: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  tituloGrafico: {
    fontFamily: theme.fontFamily.raleway.bold,
    fontSize: 24,
    color: theme.colors.bluePrimary,
  },
  legendContainer: {
    flexDirection: "column",
    marginTop: 10,
    justifyContent: "center",
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 10,
    marginBottom: 10,
  },
  legendColor: {
    width: 12,
    height: 12,
    marginRight: 5,
  },
});
