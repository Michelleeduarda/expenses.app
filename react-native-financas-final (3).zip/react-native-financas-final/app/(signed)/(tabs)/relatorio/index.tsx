import React, { useEffect, useState } from "react";
import { Text, View, Dimensions, ActivityIndicator } from "react-native";

import { styles } from "./styles";
import PieChart from "react-native-chart-kit/dist/PieChart";
import { relatorioFinancasPorMes } from "@/firebase/financa/relatorioFinancasPorMes";
import { useAuthenticate } from "@/hooks/useAuthenticate";

import { useIsFocused } from "@react-navigation/native";
import { relatorioFinancasAnual } from "@/firebase/financa/relatorioFinancasAnual";

import { ImagemRelatorio } from "@/assets/images/imagem-relatorio";

interface SaidaPorCategoria {
  [key: string]: number;
}

interface RelatorioProps {
  saidaPorCategoria: SaidaPorCategoria;
  totalEntrada: number;
  totalSaida: number;
}

export default function Relatorio() {
  const screenWidth = Dimensions.get("window").width;
  const [carregando, setCarregando] = useState<boolean>(false);

  const [dados, setDados] = useState<RelatorioProps | undefined>(undefined);
  const [dataAno, setDataAno] = useState<RelatorioAnualProps | undefined>(
    undefined
  );

  const dataAtual = new Date();

  const mes = dataAtual.getMonth() + 1;
  const ano = dataAtual.getFullYear();

  const { user } = useAuthenticate();

  const isFocused = useIsFocused();

  const fetcherDadosAno = async () => {
    try {
      const data = await relatorioFinancasAnual(user?.uid!, ano.toString());
      setDataAno(data);
    } catch (error) {
      console.error("Erro ao buscar os dados:", error);
    }
  };
  const fetcherDadosMes = async () => {
    try {
      const data = await relatorioFinancasPorMes(user?.uid!, mes.toString());
      setDados(data);
    } catch (error) {
      console.error("Erro ao buscar os dados mes:", error);
    } finally {
      setCarregando(false);
    }

    const aa = {
      saidaPorCategoria: {
        comida: 20,
        transporte: 0,
      },
    };

    console.log(
      Object.values(aa?.saidaPorCategoria ? aa.saidaPorCategoria : {}).filter(
        (d) => {
          if (d > 0) {
            return d;
          }

          return null;
        }
      ).length
    );
  };

  useEffect(() => {
    if (isFocused && user) {
      setCarregando(true);

      fetcherDadosMes();
      fetcherDadosAno();
    }
  }, [isFocused, user]);

  const originalData = [
    {
      name: "Transporte",
      valor: dados?.saidaPorCategoria["transporte"] || 0,
      color: "#780000",
      legendFontColor: "#12335E",
      legendFontSize: 15,
    },
    {
      name: "Comida",
      valor: dados?.saidaPorCategoria["comida"] || 0,
      color: "#31572C",
      legendFontColor: "#12335E",
      legendFontSize: 15,
    },
    {
      name: "Tecnologia",
      valor: dados?.saidaPorCategoria["tecnologia"] || 0,
      color: "rgba(145, 229, 232, 0.9)",
      legendFontColor: "#12335E",
      legendFontSize: 15,
    },
    {
      name: "Entreterimento",
      valor: dados?.saidaPorCategoria["entreterimento"] || 0,
      color: "rgba(45, 33, 76, 0.9)",
      legendFontColor: "#12335E",
      legendFontSize: 15,
    },
    {
      name: "Educação",
      valor: dados?.saidaPorCategoria["educação"] || 0,
      color: "rgba(202, 210, 197, 0.9)",
      legendFontColor: "#12335E",
      legendFontSize: 15,
    },
    {
      name: "Outros",
      valor: dados?.saidaPorCategoria["outros"] || 0,
      color: "rgb(12, 22, 84)",
      legendFontColor: "#12335E",
      legendFontSize: 15,
    },
  ];

  const valorTotal = originalData.reduce(
    (total, item) => total + item.valor,
    0
  );

  const data = originalData.map((item) => ({
    ...item,
    name: `${item.name} ${((item.valor / valorTotal) * 100).toFixed(2)}%`,
    valor: item.valor,
  }));

  const chartConfig = {
    backgroundGradientFrom: "#1E2923",
    backgroundGradientFromOpacity: 0,
    backgroundGradientTo: "#08130D",
    backgroundGradientToOpacity: 0.5,
    color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 1.0,
    useShadowColorFromDataset: false,
  };

  return (
    <View style={styles.container}>
      <View style={styles.containerImagem}>
        <ImagemRelatorio />
      </View>
      {carregando ? (
        <View style={styles.containerCarregando}>
          <ActivityIndicator color={"#12335E"} size={45} />
        </View>
      ) : (
        <View style={styles.containerInterno}>
          <View style={styles.containerRelatorioAno}>
            <Text style={styles.tituloRelatorio}>Relatório Anual</Text>
            <View style={styles.containerTotalizadores}>
              <Text style={styles.tituloTotalizador}>Total de entradas</Text>
              <Text style={styles.valorEntrada}>
                R$ {dataAno?.totalEntrada.toFixed(2)}
              </Text>
            </View>
            <View style={styles.containerTotalizadores}>
              <Text style={styles.tituloTotalizador}>Total de saidas</Text>
              <Text style={styles.valorSaida}>
                R$ {dataAno?.totalSaida.toFixed(2)}
              </Text>
            </View>
          </View>
          {Object.values(
            dados?.saidaPorCategoria ? dados.saidaPorCategoria : {}
          ).filter((d) => {
            if (d > 0) {
              return d;
            }
          }).length > 0 && (
            <View style={styles.containerGrafico}>
              <Text style={styles.tituloGrafico}>Resumo mensal</Text>
              <>
                <PieChart
                  data={data}
                  width={screenWidth}
                  height={270}
                  chartConfig={chartConfig}
                  accessor={"valor"}
                  backgroundColor={"transparent"}
                  paddingLeft={"15"}
                  center={[60, 10]}
                  absolute
                  hasLegend={false}
                />
                <View style={styles.legendContainer}>
                  {data.map((item, index) => (
                    <View key={index} style={styles.legendItem}>
                      <View
                        style={[
                          styles.legendColor,
                          { backgroundColor: item.color },
                        ]}
                      />
                      <Text
                        style={{
                          color: item.legendFontColor,
                          fontSize: item.legendFontSize,
                        }}
                      >
                        {item.name}
                      </Text>
                      <Text
                        style={{
                          color: item.legendFontColor,
                          fontSize: item.legendFontSize,
                        }}
                      >
                        {" "}
                        - R$ {item.valor.toFixed(2)}
                      </Text>
                    </View>
                  ))}
                </View>
              </>
            </View>
          )}
        </View>
      )}
    </View>
  );
}
