interface RelatorioProps {
  saidaPorCategoria: SaidaPorCategoria;
  totalEntrada: number;
  totalSaida: number;
}
interface RelatorioAnualProps {
  totalEntrada: number;
  totalSaida: number;
}

interface SaidaPorCategoria {
  [key: string]: number;
}
