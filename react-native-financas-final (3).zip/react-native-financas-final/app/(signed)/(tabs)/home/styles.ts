import { theme } from "@/constants";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    backgroundColor: theme.colors.blueWhiteLight,
  },
  containerImagem: {
    width: "100%",
    position: "absolute",
  },
  containerCarregando: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  containerFiltros: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
    position: "absolute",
    zIndex: 99,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  containerTitulo: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "90%",
    height: 50,
    paddingVertical: 5,
  },
  containerIcone: {
    alignItems: "center",
    justifyContent: "flex-end",
    height: 35,
  },
  titulo: {
    fontSize: 26,
    fontFamily: theme.fontFamily.raleway.semiBold,
    color: theme.colors.bluePrimary,
  },
  containerSaldo: {
    width: "100%",
    alignItems: "flex-start",
    justifyContent: "center",
    flexDirection: "column",
    paddingHorizontal: 20,
    marginTop: 15,
  },
  tituloSaldo: {
    fontSize: 18,
    fontFamily: theme.fontFamily.raleway.regular,
    color: theme.colors.white,
  },
  textoSaldo: {
    fontSize: 26,
    fontFamily: theme.fontFamily.raleway.semiBold,
    color: theme.colors.white,
  },
  containerCards: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 20,
    paddingHorizontal: 20,
    marginTop: 15,
  },
  containerNenhumaTransacao: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
  },
  textoNenhumaTransacao: {
    fontFamily: theme.fontFamily.raleway.semiBold,
    fontSize: 18,
    color: theme.colors.bluePrimary,
  },
  containerButtonTodos: {
    width: "90%",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  containerFiltro: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.colors.bluePrimary,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  filtroSelecionado: {
    backgroundColor: theme.colors.white,
  },
  textoFiltroSelecionado: {
    color: theme.colors.bluePrimary,
  },
  textoFiltro: {
    fontSize: 16,
    fontFamily: theme.fontFamily.raleway.semiBold,
    color: theme.colors.white,
  },
});
