import { useEffect, useState } from "react";
import { View, Text, ActivityIndicator, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { DateTimePickerEvent } from "@react-native-community/datetimepicker";

import { pegandoTodasFinancas } from "@/firebase/financa/pegandoTodasFinancas";
import { financasUltimos30Dias } from "@/firebase/financa/financasUltimos30Dias";

import { useAuthenticate } from "@/hooks/useAuthenticate";

import { Header } from "@/components/Header";
import { Card } from "@/components/Card";
import { Transacoes } from "@/components/Trasacoes";

import { ImagemHome } from "@/assets/images/imagem-home";

import { styles } from "./styles";
import { useIsFocused } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { FiltrosHome } from "@/components/FiltrosHome";

export default function Home() {
  const router = useRouter();

  const [totalizadores, setTotalizadores] = useState<TotalizadoresProps>();
  const [dados, setDados] = useState<TransacoesPorData[]>([]);
  const [formFiltros, setFormFiltros] = useState<FormFiltrosProps>();

  const [abrirCalendario, setAbrirCalendario] = useState<boolean>(false);
  const [dataType, setDataType] = useState<string>("");
  const [exibirFiltro, setExibirFiltro] = useState<boolean>(false);

  const [carregandoPagina, setCarregandoPagina] = useState<boolean>(true);
  const [carregando, setCarregando] = useState<boolean>(true);
  const [filtrado, setFiltrado] = useState<boolean>(false);

  const isFocused = useIsFocused();

  const { user } = useAuthenticate();

  const handleInputChange = (field: string, value: string, icone?: string) => {
    setFormFiltros((prevState) => ({
      ...prevState,
      [field]: value,
      ...(icone && { icone: icone }),
    }));
  };

  const onChange = (event: DateTimePickerEvent, selectedDate?: Date) => {
    if (selectedDate) {
      setAbrirCalendario(false);

      setFormFiltros((prevState) => ({
        ...prevState,
        [dataType]: selectedDate,
      }));
    }
  };

  const fetcherTodasFinancas = async () => {
    setCarregando(true);

    try {
      await pegandoTodasFinancas(user!.uid).then((dadosAgrupadosPorData) => {
        setDados(dadosAgrupadosPorData!);
        setCarregando(false);
      });
    } catch (e) {
      console.log(e);
    }
  };

  const fetcherTotalizadores = async () => {
    try {
      await financasUltimos30Dias(user!.uid).then((totalizadores) => {
        setTotalizadores(totalizadores!);
        setCarregandoPagina(false);
      });
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    if (user) {
      fetcherTotalizadores();
      fetcherTodasFinancas();
    }
  }, [isFocused, user]);

  const fetcherFiltrarFinancas = async () => {
    setCarregando(true);

    try {
      await pegandoTodasFinancas(
        user!.uid,
        formFiltros?.categoria,
        formFiltros?.dataInicial,
        formFiltros?.dataFinal
      ).then((dadosAgrupadosPorData) => {
        setDados(dadosAgrupadosPorData!);
        setCarregando(false);
      });
    } catch (e) {
      console.log(e);
    }
  };

  const handleAbrirCalendario = (tipo: string) => {
    setDataType(tipo);
    setAbrirCalendario(!abrirCalendario);
  };

  const handleExibirFiltro = () => {
    setExibirFiltro(!exibirFiltro);
  };

  const handleFecharFiltro = () => {
    setExibirFiltro(false);
  };

  const handleNavigate = () => {
    router.navigate("perfil-usuario");
  };

  const handleButton = () => {
    setFormFiltros({
      categoria: undefined,
      dataInicial: undefined,
      dataFinal: undefined,
    });

    fetcherTodasFinancas();
    handleFecharFiltro();
    setFiltrado(false);
  };

  const saldo =
    parseFloat(totalizadores?.totalEntrada!) -
      parseFloat(totalizadores?.totalSaida!) || 0;

  return (
    <View style={styles.container}>
      <View style={styles.containerImagem}>
        <ImagemHome />
      </View>
      <Header handleNavigate={handleNavigate} user={user?.displayName} />
      {carregandoPagina ? (
        <View style={styles.containerCarregando}>
          <ActivityIndicator color={"#12335E"} size={50} />
        </View>
      ) : (
        <>
          <View style={styles.containerSaldo}>
            <Text style={styles.tituloSaldo}>Saldo</Text>
            <Text style={styles.textoSaldo}>R$ {saldo.toFixed(2)}</Text>
          </View>
          <View style={styles.containerCards}>
            <Card
              tipo="entrada"
              titulo="Entradas"
              valor={totalizadores?.totalEntrada || "0,00"}
            />
            <Card
              tipo="saida"
              titulo="Saidas"
              valor={totalizadores?.totalSaida || "0,00"}
            />
          </View>
          <View style={styles.containerTitulo}>
            <Text style={styles.titulo}>Transações recentes</Text>
            <TouchableOpacity
              style={styles.containerIcone}
              onPress={() => setExibirFiltro(!exibirFiltro)}
            >
              <Ionicons name="filter" size={24} color="#12335E" />
            </TouchableOpacity>
          </View>
          <View style={styles.containerButtonTodos}>
            <View
              style={[
                styles.containerFiltro,
                filtrado ? styles.filtroSelecionado : null,
              ]}
            >
              <TouchableOpacity onPress={() => handleButton()}>
                <Text
                  style={[
                    styles.textoFiltro,
                    filtrado ? styles.textoFiltroSelecionado : null,
                  ]}
                >
                  Todos
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          {exibirFiltro ? (
            <View style={styles.containerFiltros}>
              <FiltrosHome
                handleInputChange={handleInputChange}
                handleAbrirCalendario={handleAbrirCalendario}
                abrirCalendario={abrirCalendario}
                handleFecharFiltro={handleFecharFiltro}
                formData={formFiltros}
                onChange={onChange}
                dataType={dataType}
                setFiltrado={setFiltrado}
                fetcherFiltrarFinancas={fetcherFiltrarFinancas}
              />
            </View>
          ) : null}
          {dados.length === 0 ? (
            <View style={styles.containerNenhumaTransacao}>
              <Text style={styles.textoNenhumaTransacao}>
                Nenhuma Transação encontrada
              </Text>
            </View>
          ) : (
            <Transacoes
              data={dados}
              handleInputChange={handleInputChange}
              handleAbrirCalendario={handleAbrirCalendario}
              handleExibirFiltro={handleExibirFiltro}
              fetcherTodasFinancas={fetcherTodasFinancas}
              fetcherFiltrarFinancas={fetcherFiltrarFinancas}
              exibirFiltro={exibirFiltro}
              handleFecharFiltro={handleFecharFiltro}
              abrirCalendario={abrirCalendario}
              onChange={onChange}
              formData={formFiltros}
              dataType={dataType}
              carregando={carregando}
            />
          )}
        </>
      )}
    </View>
  );
}
