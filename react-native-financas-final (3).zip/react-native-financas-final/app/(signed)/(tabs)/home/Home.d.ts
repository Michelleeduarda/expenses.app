interface TransacaoProps {
  id: string;
  categoria: string;
  data: string;
  descricao: string;
  valor: number;
  tipo: string;
  usuarioId: string;
  icone?: string;
}

interface TransacoesPorData {
  data: string;
  transacoes: TransacaoProps[];
}

interface TotalizadoresProps {
  totalEntrada: string;
  totalSaida: string;
}

interface FormFiltrosProps {
  categoria?: categoria;
  dataInicial?: Date;
  dataFinal?: Date;
}
