import { Tabs } from "expo-router";

import FontAwesome from "@expo/vector-icons/FontAwesome";
import { AntDesign } from "@expo/vector-icons";
import { FontAwesome6 } from "@expo/vector-icons";
import { IconeRelatorio } from "@/assets/icon/icone-relatorio";
import { IconeUser } from "@/assets/icon/icone-user";
import { IconeHome } from "@/assets/icon/icone-home";

export default function Layout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: "#12335E",
        headerShown: false,
        tabBarStyle: {
          height: 60,
          backgroundColor: "#EBF1FC",
          borderColor: "#EBF1FC",
        },
      }}
    >
      <Tabs.Screen
        name="home/index"
        options={{
          title: "Inicio",
          tabBarIcon: ({ color }) => <IconeHome color={color} />,
        }}
      />
      <Tabs.Screen
        name="adicionar-despesa/index"
        options={{
          title: "Adicionar",
          tabBarIcon: ({ color }) => (
            <FontAwesome6 size={26} name="add" color={color} />
          ),
          tabBarHideOnKeyboard: true,
        }}
      />
      <Tabs.Screen
        name="relatorio/index"
        options={{
          title: "Histórico",
          tabBarIcon: ({ color }) => <IconeRelatorio color={color} />,
        }}
      />
      <Tabs.Screen
        name="perfil-usuario/index"
        options={{
          title: "Perfil",
          tabBarIcon: ({ color }) => <IconeUser color={color} />,
          tabBarHideOnKeyboard: true,
        }}
      />
    </Tabs>
  );
}
