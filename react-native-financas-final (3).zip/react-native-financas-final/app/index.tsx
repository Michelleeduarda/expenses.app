import React from "react";

import Login from "./(unsigned)/login";

export default function index() {
  return <Login />;
}
