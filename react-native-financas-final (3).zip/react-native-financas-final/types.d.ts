type categoria =
  | "transporte"
  | "comida"
  | "tecnologia"
  | "entretenimento"
  | "educação";

type tipo = "ENTRADA" | "SAIDA";

type FinancaData = {
  id: string;
  categoria: categoria;
  descricao: string;
  valor: number;
  tipo: tipo;
  data: string;
  usuarioId: string;
};

interface SaidaPorCategoria {
  [key: string]: number;
}

interface FinancasAgrupadasPorData {
  [key: string]: FinancaData[];
}
