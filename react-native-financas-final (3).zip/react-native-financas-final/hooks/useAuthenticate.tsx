import { useEffect, useState } from "react";
import { onAuthStateChanged, User } from "firebase/auth"
import { auth } from "../firebase/config";

export function useAuthenticate() {

    const [user, setUser] = useState<User>()

    useEffect(() => {
        const unsubscribedFromAuthStateChanged = onAuthStateChanged(auth, (u) => {
            if(u) {
                setUser(u)
            } else {
                setUser(undefined)
            }
        })
        return unsubscribedFromAuthStateChanged;
    }, [])

    return {
        user,
    }
}