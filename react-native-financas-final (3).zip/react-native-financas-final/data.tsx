import { IconeCalendario } from "./assets/icon/icone-calendario";
import { IconeCarro } from "./assets/icon/icone-carro";
import IconeComida from "./assets/icon/icone-comida";
import { IconeEducacao } from "./assets/icon/icone-educacao";
import { IconeEntradaSaida } from "./assets/icon/icone-entrada-saida";
import { IconeEntreterimento } from "./assets/icon/icone-entreterimento";
import { IconeOutros } from "./assets/icon/icone-outros";
import { IconeTecnologia } from "./assets/icon/icone-tecnologia";

interface Icones {
  [key: string]: JSX.Element;
}

export const categorias = [
  {
    nome: "transporte",
    icone: "IconeCarro",
    color: "rgba(243, 26, 26, 0.2)",
  },
  {
    nome: "comida",
    icone: "IconeComida",
    color: "rgba(2, 118, 24, 0.2)",
  },
  {
    nome: "tecnologia",
    icone: "IconeTecnologia",
    color: "rgba(50, 212, 218, 0.2)",
  },
  {
    nome: "entreterimento",
    icone: "IconeEntreterimento",
    color: "rgba(93, 50, 131, 0.2)",
  },
  {
    nome: "educação",
    icone: "IconeEducacao",
    color: "rgba(236, 225, 6, 0.2)",
  },
  {
    nome: "outros",
    icone: "IconeOutros",
    color: "rgba(215, 7, 107, 0.2)",
  },
];

export const tipo = [
  {
    nome: "saida",
    icone: "IconeEntradaSaida",
    color: "rgba(243, 26, 26, 0.2)",
  },
  {
    nome: "entrada",
    icone: "IconeEntradaSaida",
    color: "rgba(35, 185, 2, 0.2)",
  },
];

export const meses = [
  {
    nome: "Janeiro",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 1,
  },
  {
    nome: "Fevereiro",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 2,
  },
  {
    nome: "Março",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 3,
  },
  {
    nome: "Abril",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 4,
  },
  {
    nome: "Maio",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 5,
  },
  {
    nome: "Junho",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 6,
  },
  {
    nome: "Julho",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 7,
  },
  {
    nome: "Agosto",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 8,
  },
  {
    nome: "Setembro",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 9,
  },
  {
    nome: "Outubro",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 10,
  },
  {
    nome: "Novembro",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 11,
  },
  {
    nome: "Dezembro",
    icone: "IconeCalendario",
    color: "rgba(50, 140, 203, 0.14)",
    mes: 12,
  },
];

export const icones: Icones = {
  IconeCarro: <IconeCarro />,
  IconeComida: <IconeComida />,
  IconeTecnologia: <IconeTecnologia />,
  IconeEntreterimento: <IconeEntreterimento />,
  IconeEducacao: <IconeEducacao />,
  IconeOutros: <IconeOutros />,
  IconeEntradaSaida: <IconeEntradaSaida />,
  IconeCalendario: <IconeCalendario />,
};
