import { initializeApp } from "firebase/app";
import { initializeAuth, getReactNativePersistence } from "firebase/auth"
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage"
import AsyncStorage from '@react-native-async-storage/async-storage';

const firebaseConfig = {
  apiKey: "AIzaSyAWocUHfq7qn0vjzWuXefUSaJxTe_AZUIY",
  authDomain: "projeto-4-4f5e7.firebaseapp.com",
  projectId: "projeto-4-4f5e7",
  storageBucket: "projeto-4-4f5e7.appspot.com",
  messagingSenderId: "1074413668132",
  appId: "1:1074413668132:web:1062a02680be34fcf315b1"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage)
})
export const storage = getStorage(app)
export const db = getFirestore(app)