import {
  collection,
  where,
  query,
  orderBy,
  getDocs,
  sum,
  getAggregateFromServer,
} from "firebase/firestore";
import { db } from "../config";
import dayjs from "dayjs";

export async function relatorioFinancasPorMes(usuarioId: string, mes: string) {
  const categorias = [
    "transporte",
    "comida",
    "tecnologia",
    "entreterimento",
    "educação",
    "outros",
  ];

  const anoAtual = dayjs().year();
  const diaInicialString = anoAtual + "-" + mes + "-" + "01";
  const diaFinalString =
    anoAtual + "-" + mes + "-" + dayjs(diaInicialString).daysInMonth();

  const dataInicial = dayjs(diaInicialString).format("YYYY-MM-DD");
  const dataFinal = dayjs(diaFinalString).format("YYYY-MM-DD");

  const financaCollection = collection(db, "financas");
  const data: FinancaData[] = [];
  const saidaPorCategoria: SaidaPorCategoria = {};

  // retornar as saidas dos valores por categoria
  try {
    const q = query(
      financaCollection,
      where("usuarioId", "==", usuarioId),
      orderBy("data", "desc")
    );

    const snapshot = await getDocs(q);

    snapshot.forEach((doc) => {
      const dData = doc.data();
      data.push({
        id: doc.id,
        categoria: dData.categoria,
        descricao: dData.descricao,
        valor: dData.valor,
        tipo: dData.tipo,
        data: dData.data,
        usuarioId: dData.usuarioId,
      });
    });

    categorias.forEach((cat) => {
      const saida = data.reduce((acc, d) => {
        if (d.categoria === (cat as categoria) && d.tipo === "SAIDA") {
          return acc + d.valor;
        }
        return acc;
      }, 0.0);

      saidaPorCategoria[cat as string] = saida;
    });
  } catch (e) {
    console.log(e);
  }

  // retornar valor positivo e negativo total do mes
  const qSaida = query(
    financaCollection,
    where("usuarioId", "==", usuarioId),
    where("data", ">=", dataInicial),
    where("data", "<=", dataFinal),
    where("tipo", "==", "SAIDA")
  );

  const qEntrada = query(
    financaCollection,
    where("usuarioId", "==", usuarioId),
    where("data", ">=", dataInicial),
    where("data", "<=", dataFinal),
    where("tipo", "==", "ENTRADA")
  );

  try {
    const aggSaida = await getAggregateFromServer(qSaida, {
      maxSaida: sum("valor"),
    });

    const aggEntrada = await getAggregateFromServer(qEntrada, {
      maxEntrada: sum("valor"),
    });

    return {
      saidaPorCategoria: saidaPorCategoria,
      totalEntrada: Number(aggEntrada.data().maxEntrada.toFixed(2)),
      totalSaida: Number(aggSaida.data().maxSaida.toFixed(2)),
    };
  } catch (e) {
    console.log(e);
  }
}
