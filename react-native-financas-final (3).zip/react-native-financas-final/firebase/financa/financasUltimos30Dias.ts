import { collection, where, query, orderBy, getDocs, sum, getAggregateFromServer, limit } from "firebase/firestore";
import { db } from "../config";
import dayjs from "dayjs";

export async function financasUltimos30Dias(
    usuarioId: string
) {

    // Pegar a data atual
    const financaCollection = collection(db, "financas")
    const q = query(financaCollection, where("usuarioId", "==", usuarioId), orderBy("data", "desc"), limit(1))
    let dataAtual;

    try {
        const snapshot = await getDocs(q!)

        snapshot.forEach(d => {
            dataAtual = d.data().data
        })
    } catch(e) {
        console.log(e)
        throw e;
    }

    if(!dataAtual) {
        return null
    }

    const data30DiasAtras = dayjs(dataAtual).add(-30, "day").format("YYYY-MM-DD")

    const qSaida = query(
        financaCollection, 
        where("usuarioId", "==", usuarioId),
        where("data", ">=", data30DiasAtras),
        where("data", "<=", dataAtual),
        where("tipo", "==", "SAIDA")
    )

    const qEntrada = query(
        financaCollection, 
        where("usuarioId", "==", usuarioId),
        where("data", ">=", data30DiasAtras),
        where("data", "<=", dataAtual),
        where("tipo", "==", "ENTRADA")
    )

    try {
        const aggSaida = await getAggregateFromServer(qSaida, {
            maxSaida: sum("valor")
        })

        const aggEntrada = await getAggregateFromServer(qEntrada, {
            maxEntrada: sum("valor")
        })
        
        return {
            totalEntrada: aggEntrada.data().maxEntrada.toFixed(2),
            totalSaida: aggSaida.data().maxSaida.toFixed(2)
        }
    } catch(e) {
        console.log(e)
    }
}