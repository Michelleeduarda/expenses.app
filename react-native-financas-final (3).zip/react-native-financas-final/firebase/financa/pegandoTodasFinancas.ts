import { collection, where, query, orderBy, getDocs } from "firebase/firestore";
import { db } from "../config";
import dayjs from "dayjs";

export async function pegandoTodasFinancas(
  usuarioId: string,
  categoria?: categoria,
  dataInicial?: Date,
  dataFinal?: Date
) {
  const financaCollection = collection(db, "financas");

  const starterDate = dayjs(dataInicial).format("YYYY-MM-DD");
  const finalDate = dayjs(dataFinal).format("YYYY-MM-DD");

  console.log(starterDate)

  let q;

  if (categoria && !dataInicial) {
    q = query(
      financaCollection,
      where("usuarioId", "==", usuarioId),
      where("categoria", "==", categoria),
      orderBy("data", "desc")
    );
  } else if (dataInicial && !categoria) {
    q = query(
      financaCollection,
      where("usuarioId", "==", usuarioId),
      where("data", ">=", starterDate),
      where("data", "<=", finalDate),
      orderBy("data", "desc")
    );
  } else if (categoria && dataInicial) {
    q = query(
      financaCollection,
      where("usuarioId", "==", usuarioId),
      where("categoria", "==", categoria),
      where("data", ">=", starterDate),
      where("data", "<=", finalDate),
      orderBy("data", "desc")
    );
  } else {
    q = query(
      financaCollection,
      where("usuarioId", "==", usuarioId),
      orderBy("data", "desc")
    );
  }

  const dadosAgrupadosPorData: TransacoesPorData[] = [];

  try {
    const snapshot = await getDocs(q!);

    snapshot.forEach((doc) => {
      const dData = doc.data();
      const data = dData.data;

      const index = dadosAgrupadosPorData.findIndex(
        (item) => item.data === data
      );
      if (index !== -1) {
        dadosAgrupadosPorData[index].transacoes.push({
          id: doc.id,
          categoria: dData.categoria,
          descricao: dData.descricao,
          valor: dData.valor,
          tipo: dData.tipo,
          data: dData.data,
          icone: dData.icone,
          usuarioId: dData.usuarioId,
        });
      } else {
        dadosAgrupadosPorData.push({
          data: dData.data,
          transacoes: [
            {
              id: doc.id,
              categoria: dData.categoria,
              descricao: dData.descricao,
              valor: dData.valor,
              tipo: dData.tipo,
              data: dData.data,
              icone: dData.icone,
              usuarioId: dData.usuarioId,
            },
          ],
        });
      }
    });

    return dadosAgrupadosPorData;
  } catch (e) {
    console.log(e);
  }
}
