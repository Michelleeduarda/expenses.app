import { collection, where, query, orderBy, getDocs, getAggregateFromServer, sum } from "firebase/firestore";
import { db } from "../config";
import dayjs from "dayjs";

export async function relatorioFinancasAnual(
    usuarioId: string,
    ano: string
) {

    const dataInicialString = ano + "-" + "01" + "01"
    const dataFinalString = ano + "-" + "12" + dayjs(ano + "-" + "12" + "-" + "01").daysInMonth()

    const dataInicial = dayjs(dataInicialString).format("YYYY-MM-DD")
    const dataFinal = dayjs(dataFinalString).format("YYYY-MM-DD")

    const financaCollection = collection(db, "financas")

    const qSaida = query(
        financaCollection, 
        where("usuarioId", "==", usuarioId),
        where("data", ">=", dataInicial),
        where("data", "<=", dataFinal),
        where("tipo", "==", "SAIDA")
    )

    const qEntrada = query(
        financaCollection, 
        where("usuarioId", "==", usuarioId),
        where("data", ">=", dataInicial),
        where("data", "<=", dataFinal),
        where("tipo", "==", "ENTRADA")
    )

    try {
        const aggSaida = await getAggregateFromServer(qSaida, {
            maxSaida: sum("valor")
        })

        const aggEntrada = await getAggregateFromServer(qEntrada, {
            maxEntrada: sum("valor")
        })
    
        return {
            totalEntrada: Number(aggEntrada.data().maxEntrada.toFixed(2)),
            totalSaida: Number(aggSaida.data().maxSaida.toFixed(2))
        }
    } catch(e) {
        console.log(e)
    }
}