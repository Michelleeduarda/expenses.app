import { collection, addDoc } from "firebase/firestore";
import { db } from "../config";
import dayjs from "dayjs";

export async function criandoFinanca(
  categoria: string,
  descricao: string,
  valor: number,
  tipo: string,
  data: string,
  iconeNome: string,
  usuarioId: string
) {
  if (!categoria || !descricao || !valor || !tipo || !data || !iconeNome) {
    throw Error("Dados invalidos!");
  }

  const d = dayjs(data).format("YYYY-MM-DD");

  const financaCollection = collection(db, "financas");

  try {
    return await addDoc(financaCollection, {
      descricao,
      categoria,
      valor,
      tipo,
      data: d,
      icone: iconeNome,
      usuarioId,
    });
  } catch (e) {
    console.log(e);
  }
}
